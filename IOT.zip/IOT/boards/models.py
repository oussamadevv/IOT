import os

from django.db import models
from django.core.mail import send_mail
# Create your models here.
import os
from django.db import models
class Dht(models.Model):
    temp = models.FloatField(null=True)
    dt = models.DateTimeField(auto_now_add=True,null=True)
    def __str__(self):
        return str(self.temp)
def save(self, *args, **kwargs):
    if self.temp > 8:
        import telepot
        token = '5769344302:AAGmX24loRRcyxlatL9yf0LPKD9yeR6F6oo'
        rece_id = 5051882475
        bot = telepot.Bot(token)
        bot.sendMessage(rece_id, 'temperature est elevee')
        print(bot.sendMessage(rece_id, 'temperature est elevee'))

        send_mail(
            'température dépasse la normale,' + str(self.temp),
            'anomalie dans la machine',
            'oussama.makhtari@ump.ac.ma',
            ['oussama.makhtari@ump.ac.ma'],
            fail_silently=False,
        )
    return super().save(*args, **kwargs)


