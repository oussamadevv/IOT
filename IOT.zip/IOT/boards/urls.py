from . import views
from django.urls import path
from boards import views

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DhtViewSet
from django.contrib.auth import views as auth_views
router = DefaultRouter()
router.register('boards', DhtViewSet, 'temperature')
urlpatterns = [

 path('data/', views.ds18b20, name='Data'),
 path('data/courbe/', views.dht12, name='table1'),
 path('data/tables/', views.tables, name='TM'),
 path('api/', include(router.urls)),
 path('cv/', views.serve_tsv, name='csv'),
 path('', auth_views.LoginView.as_view(), name='login'),
 path('logout/', auth_views.LogoutView.as_view(), name='logout'),
 path('register/', views.register, name='register'),
]

# myapi/urls.py
# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.


