from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render, redirect, reverse
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.db.models import Max, Min ,Avg,Count


# Create your views here.py



from django.shortcuts import render

# Create your views here.
from .models import Dht
def ds18b20(request):
    tab = Dht.objects.all()
    max =Dht.objects.aggregate(Max('temp'))
    min=Dht.objects.aggregate(Min('temp'))
    moyenne=Dht.objects.aggregate(Avg('temp'))
    conteur=Dht.objects.aggregate(Count('temp'))
    listcount=list(conteur.items())
    listmin=list(min.items())
    listmax =list(max.items())
    listmoy=list(moyenne.items())
    maxx=listmax[0][1]
    nim =listmin[0][1]
    moy= listmoy[0][1]
    count1=listcount[0][1]
    print(count1)
    print(maxx)
    print(min)
    print(moy)
    s = {'tab': tab,'max':maxx , 'min':nim , 'moyenne': moy,'conteur':count1}
    return render(request, 'Accueil.html', s)


def dht12(request):
    tab = Dht.objects.all()
    s = {'tab': tab}
    return render(request, 'courbe.html', s)


def tables(request):
    tab = Dht.objects.all()
    s = {'tab': tab}
    return render(request, 'tableau.html', s)

# views.py
from rest_framework import viewsets
from .serializers import DhtSerializer
from .models import Dht

class DhtViewSet(viewsets.ModelViewSet):
 queryset = Dht.objects.all()
 serializer_class = DhtSerializer






# Views
@login_required
def home(request):
    tab = Dht.objects.all()
    s = {'tab': tab}
    return render(request, 'Accueil.html', s)


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('data')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


import csv
def serve_tsv(request):
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition']= 'attachment; filename="DATAD18b20.csv"'

    writer = csv.writer(response)
    tab = Dht.objects.all()
    writer.writerow(['Temprature','----------' ,'date'])
    for Dhtt in tab:
        writer.writerow([Dhtt.temp,'---------', Dhtt.dt])

    return response









